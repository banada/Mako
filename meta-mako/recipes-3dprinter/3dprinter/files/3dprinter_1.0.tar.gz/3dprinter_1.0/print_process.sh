echo "--Hello world!"

# when we click "print" button on 3dprinter UI, this script will be run.
# The gcode file dir is:
# /usr/share/3dprinter-1.0/static/outfile/myout.gcode
